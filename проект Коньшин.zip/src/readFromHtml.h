#include "Arduino.h"
#include "SPIFFS.h"


String readHtmlFile(String html_file_name);