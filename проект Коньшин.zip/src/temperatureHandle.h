#include "config.h"
#include "configInit.h"


void temperatureHandle();