#include "Arduino.h"
void set_timer_for_function(void (*foo)(), int time, unsigned long *counter);